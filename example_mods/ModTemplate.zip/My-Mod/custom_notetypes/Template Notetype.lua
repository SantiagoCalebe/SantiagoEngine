function onCreate()
	--Iterate over all notes
	for i = 0, getProperty('unspawnNotes.length')-1 do
		--Check if the note is an desviation note
		if getPropertyFromGroup('unspawnNotes', i, 'noteType') == 'Yourcustomnotename' then
			setPropertyFromGroup('unspawnNotes', i, 'texture', 'Yournote_assets'); --Change texture
				setPropertyFromGroup('unspawnNotes', i, 'ignoreNote', true); --Miss has no penalties
		end
	end
	--debugPrint('Script started!')
	function noteMiss(id, i, noteType, isSustainNote)
		if noteType == 'Yourcustomnotename' then
            -- Function
	end
end
end

function goodNoteHit(id, noteData, noteType, isSustainNote)
	if noteType == 'Yourcustomnotename' then
		-- Function
	end
end